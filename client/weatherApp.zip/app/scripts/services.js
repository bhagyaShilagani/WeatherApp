'use strict';
//Service to inject data dependencies into controller, make a restful api call on weatheu
angular.module('weatherApp')
  .constant("baseURL","http://localhost:3000/")
  .service('menuFactory', ['$resource', 'baseURL', function($resource, baseURL) {

    this.getForecast = function(zipcode) {
      var weatherReqURL = baseURL + "forecast/?"+zipcode;
      console.log("Sending request to Server: " + weatherReqURL);
      return $resource(weatherReqURL, {query: {isArray: false,method: 'GET'}});
    };
  }])
;
