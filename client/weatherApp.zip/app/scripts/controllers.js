'use strict';
// Controler for the DOM elements
angular.module('weatherApp')
// Controller to fetch data from wunderground.com
.controller('wunderWeatherController', ['$scope', 'menuFactory', function($scope, menuFactory) {
            $scope.showForecast = false;
            $scope.message = "";
            $scope.forecast = [];
            //OnSubmit method call
            $scope.checkWeather = function () {
                // Message to show when dat ais being fetched
                $scope.message = "Loading ...";
                console.log($scope.message);

                // sends request to the server via service class
                $scope.forecast = menuFactory.getForecast($scope.zipcode).get().$promise.then(
                  function(response) {
                      $scope.message = "Weather forecast for ZipCode: "+ $scope.zipcode;
                      //$scope.message = zipcodes.lookup($scope.zipcode);
                      $scope.showForecast = true;
                      console.log($scope.message);

                      //var forecasts = response.forecast.txt_forecast.forecastday;
                      var forecastsObj = JSON.parse(response.forecast.txt_forecast.forecastday);
                      console.log("Received forecast from server: " + forecastsObj);

                      for(var i = 0; i < forecastsObj.length; i++) {
                          var f = forecastsObj.forecast.txt_forecast.forecastday[i];
                          $scope.forecast[i] = {"day": f.title,"image":f.icon_url,"desc": f.fcttext, "metric":f.fcttext_metric};
                          console.log($scope.forecast[i]);
                      }
                      console.log($scope.message);
                      console.log("Received forecast from server: " + $scope.forecast);
                  },
                  function(response) {
                    $scope.message = "Error: " + response.status + " " + response.statusText;
                  }
                );
            };
        }])

// Controller to fetch static weather data
.controller('weatherController', ['$scope', function($scope) {
            $scope.message = "Weather Forecast from local server .... ";
            $scope.forecast = [
              {
                "day": "TODAY",
                "image":"http://icons.wxug.com/i/c/k/clear.gif",
                "desc": "Clear. Lows overnight in the low teens.",
                "metric":"Clear. Low -11C."
              },
              {
                "day": "THU",
                "image":"http://icons.wxug.com/i/c/k/clear.gif",
                "desc": "A mainly sunny sky. High 37F. Winds SW at 5 to 10 mph.",
                "metric":"Sunny. High 3C. Winds SW at 10 to 15 km/h."
              },
              {
                "day": "FRI",
                "image":"http://icons.wxug.com/i/c/k/chancerain.gif",
                "desc": "Showers in the morning, then cloudy in the afternoon. High 43F. Winds SSW at 10 to 15 mph. Chance of rain 50%.",
                "metric":"Rain showers early with overcast skies later in the day. High near 5C. Winds SSW at 10 to 15 km/h. Chance of rain 50%."
              },
              {
                "day": "SAT",
                "image":"http://icons.wxug.com/i/c/k/cloudy.gif",
                "desc": "Cloudy. High 39F. Winds NW at 10 to 20 mph.",
                "metric": "More clouds than sun. High 4C. Winds NW at 15 to 30 km/h."
              }
            ];
            console.log($scope.forecast);
        }])
;
